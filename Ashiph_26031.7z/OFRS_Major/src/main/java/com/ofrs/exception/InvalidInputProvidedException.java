package com.ofrs.exception;

public class InvalidInputProvidedException extends RuntimeException
{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public InvalidInputProvidedException(String message) {
		super(message);
	}

}
