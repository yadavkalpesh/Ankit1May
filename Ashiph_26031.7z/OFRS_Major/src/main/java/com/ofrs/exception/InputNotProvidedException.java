package com.ofrs.exception;

public class InputNotProvidedException extends RuntimeException{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public InputNotProvidedException(String message) {
		super(message);
	}

}
