package com.ofrs.exception;


public class RecordAlreadyPresentException extends RuntimeException {
	public RecordAlreadyPresentException(String s) {
		super("Record already present...");
	}
}
