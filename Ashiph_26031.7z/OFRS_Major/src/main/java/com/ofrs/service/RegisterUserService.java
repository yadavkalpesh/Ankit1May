package com.ofrs.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ofrs.model.Passenger;
import com.ofrs.model.RegisterUser;
import com.ofrs.repository.PassegerRepository;
import com.ofrs.repository.RegisterUserRepository;
import ch.qos.logback.classic.Logger;
import lombok.extern.slf4j.Slf4j; 

@Service
@Slf4j
public class RegisterUserService {
	
	Logger logger = (Logger) org.slf4j.LoggerFactory.getLogger(RegisterUserService.class);
	
	@Autowired
	RegisterUserRepository registerUserRepository;
	
	@Autowired
	PassegerRepository passengerRepo;
	
	public RegisterUser addUser(RegisterUser user) {
		logger.info("***Add user service is called***");
		return registerUserRepository.save(user);
	}
	
	public List<RegisterUser> getAllUser() {
		logger.info("***Get all user service is called***");
		return registerUserRepository.findAll();
	}
	
	public RegisterUser getUser(int userId) {
		logger.info("***Get user service is called***");
		return registerUserRepository.findById(userId).orElse(null);
	}

	public void deleteUser(int userId) {
		logger.info("***Delete user service is called***");
		registerUserRepository.deleteById(userId);
	}
	
	public RegisterUser updateUser(int userId, RegisterUser user) {
		logger.info("***Update user service is called***");
		return registerUserRepository.save(user);
	}
	
	public RegisterUser findByuserEmail(String userEmail) {
		logger.info("***Find by user email service is called***");
		return registerUserRepository.findByuserEmail(userEmail);
	}

}
