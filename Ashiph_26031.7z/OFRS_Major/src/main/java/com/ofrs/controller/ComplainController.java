package com.ofrs.controller;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.ofrs.exception.RecordNotFoundException;
import com.ofrs.model.Complain;
import com.ofrs.service.ComplainService;

import ch.qos.logback.classic.Logger;

@RestController
@CrossOrigin("http://localhost:4200/")
public class ComplainController {

	@Autowired
	private ComplainService complainService;
	
	Logger logger = (Logger) org.slf4j.LoggerFactory.getLogger(ComplainController.class);
	
	// Add complain to database.
	@PostMapping("/addComplain")
	public ResponseEntity<String> addComplain(@RequestBody Complain complain){
		complainService.addComplain(complain);
		logger.info("Add complain controller called....");
		return new ResponseEntity<String>("complain added!!!",HttpStatus.OK);
	}
	
	
	//Fetch all complain from database.
	@GetMapping("/getAllComplain")
	public ResponseEntity<List<Complain>> getAllComplain(){
		List<Complain> compalinList = complainService.getAllComplain();
		logger.info("Get all complain controller called.....");
		return new ResponseEntity<List<Complain>>(compalinList,HttpStatus.OK);
	}
	
	
	//Fetch complainById from database.
	@GetMapping("/getComplain/{complainId}")
	public ResponseEntity<?> getComplainById(@Valid @PathVariable int complainId){
		
		Optional<?> complain = complainService.getAllComplain(complainId);
		
		if(complain == null) {
			throw  new RecordNotFoundException("No record found....");
		}
		logger.info("Get complain by id controller called.....");
		return new ResponseEntity<>(complain,HttpStatus.OK);
	}
	
	
	//Delete complainById from database.
	@DeleteMapping("/deleteComplain/{complainId}")
	public ResponseEntity<String> deleteBookingById(@Valid @PathVariable int complainId){
		
		complainService.deleteComplainById(complainId);
		if(complainId <= 0) {
			throw new RecordNotFoundException("No reccord found....");
		}
		logger.info("Delete complain controller called......");
		return new ResponseEntity<String>("Complain deleted succesfully.....",HttpStatus.OK);
	}
	
	
	//Update complain using complainId
	@PutMapping("/updateComplain/{complainId}")
	public ResponseEntity<String> updateComplainById(@Valid @PathVariable int complainId, @RequestBody Complain complain){
		
		complain.setComplainId(complainId);
		complainService.updateComplainById(complainId,complain);
		logger.info("Update complain controller called......");
		return new ResponseEntity<String>("Complain details updated successfully...",HttpStatus.OK);
		
	}
	
	

}
