package com.ofrs.controller;

import java.util.List;



import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.ofrs.exception.RecordAlreadyPresentException;
import com.ofrs.exception.RecordNotFoundException;
import com.ofrs.model.BookTicket;
import com.ofrs.model.Offer;
import com.ofrs.model.Offerdto;
import com.ofrs.service.BookingTicketService;

import ch.qos.logback.classic.Logger;
import lombok.extern.slf4j.Slf4j;

@RestController
@CrossOrigin("http://localhost:4200/")
@Slf4j
public class BookingTicketController {
	
	@Autowired
	BookingTicketService bookTicketService;
	
	Logger logger = (Logger) org.slf4j.LoggerFactory.getLogger(BookingTicketController.class);
	
	//add new booking to database
	@PostMapping("/newBooking")
	public ResponseEntity<?> addBooking(@Valid @RequestBody Offerdto odto)
	{	
		BookTicket bookModel = Offerdto.toOfferModel(odto); 
		bookTicketService.addBooking(bookModel);
		logger.info("New create booking controller called....");
		return new ResponseEntity<String>("New booking added successfully.....",HttpStatus.OK);
	}

	//get all bookings from database
	@GetMapping("/getAllBookings")
	
	public ResponseEntity<List<BookTicket>> getAllBookings()
	{
		List<BookTicket> list = bookTicketService.getAllBookings();
		
		if(list.isEmpty()) {
			throw new RecordNotFoundException("No data found....");
		}
		logger.info("Get all booking controller called....");
		return new ResponseEntity<>(list,HttpStatus.OK);
	}
	
	//update booking in database with bookingId
	@PutMapping("/updateBooking/{id}")
	public ResponseEntity<String> updateBookingById(@Valid @PathVariable int id,@RequestBody BookTicket bookTicket)
	{
		bookTicket.setBookingId(id);
		bookTicketService.updateBookingById(id,bookTicket);
		logger.info("Update booking controller called....");
		return new ResponseEntity<String>("Booking Details Updated Successfully....",HttpStatus.OK);
	}
	
	
	//fetch booking details from database using bookingId.
	@GetMapping("/getBooking/{bookingId}")
	public ResponseEntity<?> getBookingById(@Valid @PathVariable int bookingId)
	{
		Optional<?> bookTicket = bookTicketService.getAllBookings(bookingId);
		
		if(bookTicket == null)
		{
			throw new RecordNotFoundException("No record found....");
		}
		logger.info("Getbooking by id booking controller called....");
		return new ResponseEntity<>(bookTicket,HttpStatus.OK);
	}
	
	//delete booking from database using bookingId.
	@DeleteMapping("/deleteBooking/{bookingId}")
	public ResponseEntity<String> deleteBookingById(@Valid @PathVariable int bookingId)
	{
		bookTicketService.deleteBookingById(bookingId);
		if(bookingId <= 0 ) {
			throw new RecordNotFoundException("No reccord found....");
		}
		logger.info("Delete booking controller called....");
		return new ResponseEntity<String>("Customer Deleted Succesfully.....",HttpStatus.OK);
	}
	
	//searching flight according to source, destination and depatureTime
		@GetMapping("/getAllTicketsByUserId")
		public ResponseEntity<List<BookTicket>> getTicketByUserId(@RequestParam int userId){
			logger.info("searchFlight Controller is called********");
			List<BookTicket> ticketList = bookTicketService.getTicketByUserId(userId);
			return new ResponseEntity<List<BookTicket>>(ticketList,HttpStatus.OK);
		}
	

	
}
