package com.ofrs.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.ofrs.exception.InputNotProvidedException;
import com.ofrs.exception.InvalidInputProvidedException;
import com.ofrs.exception.RecordAlreadyPresentException;
import com.ofrs.exception.RecordNotFoundException;
import com.ofrs.model.Passenger;
import com.ofrs.model.RegisterUser;
import com.ofrs.model.UserPassengerDTO;
import com.ofrs.service.PassengerService;
import com.ofrs.service.RegisterUserService;

import ch.qos.logback.classic.Logger;
import lombok.extern.slf4j.Slf4j;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
@Slf4j
public class RegisterUserController {
	
	@Autowired
	RegisterUserService registerUserService;
	
	@Autowired
	PassengerService passengerService;
	
	Logger logger = (Logger) org.slf4j.LoggerFactory.getLogger(RegisterUserController.class);
	
	@PostMapping("/login")
	public ResponseEntity<?> loginUser(@RequestBody RegisterUser user){

		if(user==null) {
			throw new RecordNotFoundException("No user Found");
		}
		
		if(user.getUserEmail().isEmpty() || user.getUserEmail().length() ==0) {
			throw new InputNotProvidedException("Enter user email");
		}
		
		String registered_email = registerUserService.findByuserEmail(user.getUserEmail()).getUserEmail();
		// if req can add find user by contact number
		if(registered_email.isEmpty()) {
			throw new RecordNotFoundException("You are not registered");
		}
		
		RegisterUser user_new =  registerUserService.findByuserEmail(user.getUserEmail());
		System.out.println(user_new);
		
		if(user_new.getPassword().equals(user.getPassword())) {
			logger.info("***User login controller is called***");
			
			return new ResponseEntity<RegisterUser>(user_new, HttpStatus.OK);
		}
		else
			return (ResponseEntity<?>) ResponseEntity.internalServerError();
	}
	
	@PostMapping("/addUser")
	public ResponseEntity<?> addUser(@RequestBody RegisterUser registerUser){
		
		if(registerUser.getUserName().isEmpty() || registerUser.getUserName().length() ==0) {
			throw new InputNotProvidedException("User name cannot be empty");
		}
		
		if(registerUser.getUserEmail().isEmpty() || registerUser.getUserEmail().length() ==0) {
			throw new InputNotProvidedException("User email cannot be empty");
		}
		
		if(registerUser.getContactNumber().isEmpty() || registerUser.getContactNumber().length() ==0) {
			throw new InputNotProvidedException("Contact number cannot be empty");
		}
		
		if(registerUser.getPassword().isEmpty() || registerUser.getPassword().length() == 0 || registerUser.getPassword().length() < 9 ) {
			throw new InputNotProvidedException("Password cannot be empty and must be greater than 8 characters");
		}
		
		String duplicate_email = registerUserService.findByuserEmail(registerUser.getUserEmail()).getUserEmail();
		// if req can add find user by contact number
		if(registerUser.getUserEmail() == duplicate_email ) {
			throw new RecordAlreadyPresentException("Your email is already registered");
		}
		
		RegisterUser user_new = registerUserService.addUser(registerUser);
		logger.info("***Add user controller is called***");
		return new ResponseEntity<RegisterUser>(user_new, HttpStatus.OK);
	}
	
	@GetMapping("/getAllUser")
	public ResponseEntity<List<RegisterUser>> getAllUser(){
		List<RegisterUser> userList = new ArrayList<RegisterUser>();
		userList = registerUserService.getAllUser();
		
		if(userList.isEmpty()) {
			throw new RecordNotFoundException("No users Found");
		}
		
		logger.info("***Get all user controller is called***");
		return new ResponseEntity<>(userList, HttpStatus.OK);
	}
	
	@GetMapping("/getUser/{userId}")
	public ResponseEntity<RegisterUser> getUser(@PathVariable int userId){
		RegisterUser user = registerUserService.getUser(userId);
		
		if(user.equals(null)) {
			throw new RecordNotFoundException("No user Found");
		}
		
		logger.info("***Get user controller is called***");
		return new ResponseEntity<>(user, HttpStatus.OK);
	}
	
	@DeleteMapping("/deleteUser/{userId}")
	public ResponseEntity<String> deleteUser(@PathVariable int userId) {
		
		if(userId <= 0) {
			throw new InvalidInputProvidedException("Invalid Input Provided");
		}
		
		registerUserService.deleteUser(userId);
		logger.info("***Delete user controller is called***");
		return new ResponseEntity<>("User deleted successfully", HttpStatus.OK);
	}
	
	@PutMapping("/updateUser/{userId}")
	public ResponseEntity<RegisterUser> updateUser(@PathVariable int userId, @RequestBody RegisterUser user){		
		
		if(user.equals(null)) {
			throw new InputNotProvidedException("User is empty");
		}
		if(user.getUserId() <= 0) {
			throw new InvalidInputProvidedException("Invalid Input Provided");
		}
		
		RegisterUser user_new = registerUserService.updateUser(userId, user);
		logger.info("***Update user controller is called***");
		return new ResponseEntity<>(user_new, HttpStatus.OK);
	}
	
	@GetMapping("/findByuserEmail/{userEmail}")
	public ResponseEntity<RegisterUser> findByuserEmail(@PathVariable String userEmail){
		RegisterUser user = registerUserService.findByuserEmail(userEmail);
		logger.info("***Find by email user controller is called***");
		return new ResponseEntity<>(user, HttpStatus.OK);
	}
	
	@PostMapping("/addPassenger")
	public ResponseEntity<?> addPassenger(@RequestBody UserPassengerDTO upDto){
		Passenger passenger = UserPassengerDTO.toEntityPassenger(upDto);
		passengerService.addPassenger(passenger);
		
		return ResponseEntity.ok(passenger);
	}
}