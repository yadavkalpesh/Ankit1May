export class Complain{
    complainId!:number;
    complainDetails!:string;
    complainStatus!:string;
    user!:any;
} 