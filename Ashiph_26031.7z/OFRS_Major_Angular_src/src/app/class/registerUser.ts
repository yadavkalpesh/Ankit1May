export class RegisterUser{
    userId!:number;
    userName!:string;
    userEmail!:string;
    imagePath!:string;
    contactNumber!:string;
    password!:string;
}