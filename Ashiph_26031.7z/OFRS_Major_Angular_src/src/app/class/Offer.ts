export class Offer {
    offerId!:number;
    offerName!:string;
    offerCode!:string;
    offerAmount!: number;
}
