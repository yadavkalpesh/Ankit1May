export class Flights {
    
    flightId:number=0;
    flightName:string="";
    source!:string;
    destination!:string;
    departureDate!:Date;
    departureTime!:string;
    stops!:string;
    totalSeats!:number;
    basePrice!:number;
   
}
