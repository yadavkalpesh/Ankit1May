export class Feedback{
    feedbackId!:number;
    feedbackDetails!:string;
    rating!:number;
    user!:number;
}