export class Passenger{

    passengerId!:number;
    passengerName!:string;
    gender!:string;
    contactNumber!:string;
    userId!:number;

}