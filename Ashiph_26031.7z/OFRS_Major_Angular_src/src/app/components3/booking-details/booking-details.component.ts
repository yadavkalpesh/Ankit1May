import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { BookTicket } from 'src/app/class/bookTicket';
import { Flights } from 'src/app/class/flights';
import { TicketService } from '../service/ticket.service';
import { UserHomeService } from '../service/user-home.service';

@Component({
  selector: 'app-booking-details',
  templateUrl: './booking-details.component.html',
  styleUrls: ['./booking-details.component.scss']
})
export class BookingDetailsComponent implements OnInit {

  bookTicket: BookTicket[] = [];

  userId: number = 1;

  flightId!:number;

  flight:Flights = new Flights();

  constructor(private TicketService: TicketService, private router: Router, private fb: FormBuilder, private activeroute: ActivatedRoute,private userHomeService:UserHomeService) { }

  ngOnInit(): void {
    // this.flightId = this.activeroute.snapshot.params[`id`];
    // this.getBooking();

    this.TicketService.getAllTicketByUserId(this.userId).subscribe((data: any) => {
      console.table(data);
      this.bookTicket = data;
      console.log("all list on booking details ts: ",this.bookTicket);
    })
    
    // this.userHomeService.getFlightById(this.flightId).subscribe(data =>{
    //   this.flight = data;
    // }, error => console.log(error));
  }

  getBooking() {
   
  }

}
