import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Complain } from 'src/app/class/complain';
import { RegisterUser } from 'src/app/class/registerUser';
import { ComplainService } from '../service/complain.service';

@Component({
  selector: 'app-complain',
  templateUrl: './complain.component.html',
  styleUrls: ['./complain.component.scss']
})
export class ComplainComponent implements OnInit {

  constructor(private complainService:ComplainService,private router: Router, private fb: FormBuilder, private activeroute: ActivatedRoute) { }

  complain:Complain = new Complain();

  user:RegisterUser = new RegisterUser(); 

  

  ngOnInit(): void {
  }

  //not working need some changes while passing userId
  onSubmit(){
    this.complain.complainStatus= "pending";
    this.user.userId = 1;
    console.log(this.user.userId);
    this.complain.user.user_id= 1;
    this.saveFlight();

    console.log(this.complain);
  }

  saveFlight(){
    this.complainService.addComplain(this.complain).subscribe((data : any ) =>{
      console.log(data);
      console.log("complain added");
    },
    error => console.log(error));
  }

  

}
