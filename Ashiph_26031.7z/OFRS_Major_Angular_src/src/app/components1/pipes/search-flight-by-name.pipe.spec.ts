import { SearchFlightByNamePipe } from './search-flight-by-name.pipe';

describe('SearchFlightByNamePipe', () => {
  it('create an instance', () => {
    const pipe = new SearchFlightByNamePipe();
    expect(pipe).toBeTruthy();
  });
});
