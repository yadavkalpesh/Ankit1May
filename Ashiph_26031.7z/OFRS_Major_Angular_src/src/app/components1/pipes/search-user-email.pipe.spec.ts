import { SearchUserEmailPipe } from './search-user-email.pipe';

describe('SearchUserEmailPipe', () => {
  it('create an instance', () => {
    const pipe = new SearchUserEmailPipe();
    expect(pipe).toBeTruthy();
  });
});
