import { SearchByOfferCodePipe } from './search-by-offer-code.pipe';

describe('SearchByOfferCodePipe', () => {
  it('create an instance', () => {
    const pipe = new SearchByOfferCodePipe();
    expect(pipe).toBeTruthy();
  });
});
